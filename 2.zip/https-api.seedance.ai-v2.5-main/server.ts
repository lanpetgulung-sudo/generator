import express from 'express';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

/**
 * Seedance 2.5 proxy for BytePlus ModelArk (official API).
 * The API key stays on the server (ARK_API_KEY) and is never sent to the browser.
 * Docs: https://ai.byteplus.com/ark/region:ap-southeast-1/docs/create-video-generation-task-api
 */
const ARK_API_KEY = process.env.ARK_API_KEY || '';
const ARK_BASE_URL = (process.env.ARK_BASE_URL || 'https://ark.ap-southeast.bytepluses.com/api/v3').replace(/\/+$/, '');
const ARK_MODEL = process.env.ARK_MODEL || 'dreamina-seedance-2-5-260628';
const PORT = Number(process.env.PORT || 3000);

async function ark(pathname: string, init: RequestInit = {}) {
  if (!ARK_API_KEY) {
    throw Object.assign(new Error('ARK_API_KEY belum diisi di file .env pada server.'), { status: 500 });
  }
  const res = await fetch(`${ARK_BASE_URL}${pathname}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${ARK_API_KEY}`,
      ...(init.headers || {}),
    },
  });
  const text = await res.text();
  let data: any = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!res.ok) {
    const msg = data?.error?.message || data?.message || data?.raw || res.statusText;
    throw Object.assign(new Error(`BytePlus API [${res.status}]: ${msg}`), { status: res.status });
  }
  return data;
}

const isHttp = (u?: string) => !!u && /^https?:\/\//i.test(u);
const isImageOk = (u?: string) => !!u && (isHttp(u) || /^data:image\/[a-z0-9.+-]+;base64,/.test(u) || u.startsWith('asset://'));

function buildBody(p: any) {
  const type = p.type as string;
  let prompt: string = String(p.prompt || '').trim();
  if (p.negativePrompt) prompt += `\nAvoid: ${p.negativePrompt}`;
  if (!prompt && type === 'TEXT_TO_VIDEO') throw Object.assign(new Error('Prompt wajib diisi.'), { status: 400 });

  const content: any[] = [];
  const body: any = {
    model: ARK_MODEL,
    resolution: p.resolution || '720p',
    generate_audio: p.hasAudio !== false,
    watermark: false,
    output_format: String(p.outputFormat || 'MP4').toLowerCase(),
  };
  // Seedance 2.5: duration is [4,30] or -1
  const dur = Math.round(Number(p.duration));
  body.duration = Number.isFinite(dur) ? Math.min(30, Math.max(4, dur)) : -1;

  if (type === 'TEXT_TO_VIDEO') {
    body.ratio = p.aspectRatio || 'adaptive';
  } else if (type === 'IMAGE_TO_VIDEO') {
    if (!isImageOk(p.firstFrameUrl)) throw Object.assign(new Error('Gambar frame pertama harus URL publik (http/https) atau data base64.'), { status: 400 });
    content.push({ type: 'image_url', image_url: { url: p.firstFrameUrl }, role: 'first_frame' });
    if (p.lastFrameUrl) {
      if (!isImageOk(p.lastFrameUrl)) throw Object.assign(new Error('Gambar frame terakhir tidak valid.'), { status: 400 });
      content.push({ type: 'image_url', image_url: { url: p.lastFrameUrl }, role: 'last_frame' });
    }
    body.ratio = 'adaptive'; // 2.5 only supports adaptive for first/last-frame tasks
  } else if (type === 'REFERENCE_TO_VIDEO') {
    const refs: string[] = (p.referenceUrls || []).filter(Boolean);
    if (!refs.length) throw Object.assign(new Error('Butuh minimal satu gambar referensi.'), { status: 400 });
    refs.forEach((u) => {
      if (!isImageOk(u)) throw Object.assign(new Error('Gambar referensi harus URL publik atau data base64.'), { status: 400 });
      content.push({ type: 'image_url', image_url: { url: u }, role: 'reference_image' });
    });
    const notes = (p.referenceInstructions || []).map((t: string, i: number) => (t ? `@Image${i + 1}: ${t}` : '')).filter(Boolean);
    if (notes.length) prompt += `\n${notes.join('\n')}`;
    body.ratio = p.aspectRatio || 'adaptive';
    body.omni_reference_task_type = 'reference';
  } else if (type === 'VIDEO_TO_VIDEO') {
    if (!isHttp(p.sourceVideoUrl)) throw Object.assign(new Error('Video sumber harus URL publik (http/https). File lokal/blob tidak bisa dibaca BytePlus.'), { status: 400 });
    content.push({ type: 'video_url', video_url: { url: p.sourceVideoUrl }, role: 'reference_video' });
    body.ratio = 'adaptive';
    body.duration = -1;
    body.omni_reference_task_type = 'edit';
  } else {
    throw Object.assign(new Error(`Tipe generasi tidak dikenal: ${type}`), { status: 400 });
  }

  if (prompt) content.unshift({ type: 'text', text: prompt });
  body.content = content;
  return body;
}

const STATUS: Record<string, string> = {
  queued: 'QUEUED', running: 'PROCESSING', succeeded: 'SUCCEEDED',
  failed: 'FAILED', cancelled: 'CANCELLED', expired: 'FAILED',
};

async function main() {
  const app = express();
  app.use(express.json({ limit: '70mb' }));

  app.get('/api/seedance/health', async (_req, res) => {
    if (!ARK_API_KEY) {
      return res.status(200).json({ ok: false, message: 'ARK_API_KEY belum diisi di file .env pada server.' });
    }
    try {
      await ark('/contents/generations/tasks?page_size=1');
      res.json({ ok: true, message: `Terhubung ke BytePlus ModelArk. Model: ${ARK_MODEL}` });
    } catch (e: any) {
      res.json({ ok: false, message: e.message });
    }
  });

  app.post('/api/seedance/tasks', async (req, res) => {
    try {
      const data = await ark('/contents/generations/tasks', { method: 'POST', body: JSON.stringify(buildBody(req.body || {})) });
      res.json({ taskId: data.id });
    } catch (e: any) {
      res.status(e.status || 500).json({ error: e.message });
    }
  });

  app.get('/api/seedance/tasks/:id', async (req, res) => {
    try {
      const t = await ark(`/contents/generations/tasks/${encodeURIComponent(req.params.id)}`);
      const status = STATUS[t.status] || 'PROCESSING';
      let progress = 0;
      if (status === 'SUCCEEDED') progress = 100;
      else if (status === 'QUEUED') progress = 5;
      else if (status === 'PROCESSING') {
        const elapsed = Math.max(0, Date.now() / 1000 - (t.created_at || Date.now() / 1000));
        const expected = Math.max(60, (t.duration > 0 ? t.duration : 10) * 8);
        progress = Math.min(92, Math.max(10, Math.round((elapsed / expected) * 90)));
      }
      res.json({
        status, progress,
        stageText: t.status === 'queued' ? 'Menunggu antrean BytePlus...' : t.status === 'running' ? 'Seedance 2.5 sedang merender...' : undefined,
        videoUrl: t.content?.video_url,
        thumbnailUrl: t.content?.last_frame_url,
        errorMessage: t.error ? `${t.error.code}: ${t.error.message}` : t.status === 'expired' ? 'Task kedaluwarsa.' : undefined,
        seed: t.seed,
      });
    } catch (e: any) {
      res.status(e.status || 500).json({ error: e.message });
    }
  });

  // Proxy for downloading the finished video (avoids browser CORS on the signed URL)
  app.get('/api/seedance/download', async (req, res) => {
    const url = String(req.query.url || '');
    if (!isHttp(url)) return res.status(400).json({ error: 'URL tidak valid.' });
    try {
      const up = await fetch(url);
      if (!up.ok || !up.body) return res.status(502).json({ error: `Gagal mengunduh (${up.status}).` });
      res.setHeader('Content-Type', up.headers.get('content-type') || 'video/mp4');
      res.setHeader('Content-Disposition', 'attachment; filename="seedance-video.mp4"');
      const buf = Buffer.from(await up.arrayBuffer());
      res.send(buf);
    } catch (e: any) {
      res.status(502).json({ error: e.message });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const dist = path.resolve(process.cwd(), 'dist');
    app.use(express.static(dist));
    app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Seedance Studio: http://localhost:${PORT}  (ARK key ${ARK_API_KEY ? 'set' : 'MISSING'}, model ${ARK_MODEL})`);
  });
}

main();
