import {
  IVideoProvider,
  VideoGenerationParams,
  ProviderTaskResponse,
  ProviderPollResponse,
  Resolution
} from '../../types/index';

/**
 * Production Seedance 2.5 Provider Client
 * Communicates with the authorized Seedance API endpoints.
 */
export class SeedanceProvider implements IVideoProvider {
  public name = 'Seedance 2.5 Live (BytePlus ModelArk)';
  public isMock = false;

  // The browser only talks to our own server (/api/seedance/*).
  // The BytePlus API key lives on the server in ARK_API_KEY.
  constructor(_apiKey?: string, _baseUrl?: string) {}

  public calculateCost(duration: number, resolution: Resolution): number {
    const basePerSecond = resolution === '1080p' ? 2 : 1;
    return Math.max(1, Math.ceil(duration * basePerSecond));
  }

  private async request<T>(endpoint: string, options: RequestInit): Promise<T> {
    const response = await fetch(`/api/seedance${endpoint}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...((options.headers as Record<string, string>) || {}) },
    });
    if (!response.ok) {
      let errMsg = response.statusText;
      try {
        const payload = await response.json();
        errMsg = payload.error || payload.message || JSON.stringify(payload);
      } catch {
        // keep status text
      }
      throw new Error(errMsg);
    }
    return response.json() as Promise<T>;
  }

  private async submit(params: VideoGenerationParams, waitFactor: number): Promise<ProviderTaskResponse> {
    const res = await this.request<{ taskId: string }>('/tasks', { method: 'POST', body: JSON.stringify(params) });
    return { taskId: res.taskId, status: 'QUEUED', estimatedWaitTime: Math.round(params.duration * waitFactor) };
  }

  public generateTextToVideo(params: VideoGenerationParams) { return this.submit(params, 4); }
  public generateImageToVideo(params: VideoGenerationParams) { return this.submit(params, 4); }
  public generateReferenceToVideo(params: VideoGenerationParams) { return this.submit(params, 5); }
  public generateVideoToVideo(params: VideoGenerationParams) { return this.submit(params, 5); }

  public async checkStatus(taskId: string): Promise<ProviderPollResponse> {
    return this.request<ProviderPollResponse>(`/tasks/${encodeURIComponent(taskId)}`, { method: 'GET' });
  }

  public async downloadGeneratedVideo(videoUrl: string, filename: string): Promise<void> {
    const link = document.createElement('a');
    link.href = `/api/seedance/download?url=${encodeURIComponent(videoUrl)}`;
    link.download = filename.endsWith('.mp4') ? filename : `${filename}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
