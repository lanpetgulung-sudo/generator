# Seedance Studio - cara menjalankan (versi BytePlus ModelArk)

1. Buat akun BytePlus, aktifkan model Seedance 2.5, lalu buat API key di konsol ModelArk.
   (Aktivasi model 2.5 membutuhkan saldo di atas USD 30 atau paket Seedance.)
2. Salin `.env.example` menjadi `.env`, lalu isi `ARK_API_KEY`.
3. Jalankan:
   npm install --legacy-peer-deps
   npm run dev
4. Buka http://localhost:3000 -> Studio Settings -> matikan Simulation/Mock Mode -> Test Connection.

Catatan:
- API key hanya ada di server (.env), tidak lagi di browser.
- Gambar boleh URL publik atau upload (base64). Video sumber (Video-to-Video) harus URL publik.
- Seedance 2.5 tidak menerima foto wajah manusia asli sebagai referensi.
- Link video hasil hanya berlaku 24 jam; segera unduh.
- Angka "Credits" di aplikasi hanya hitungan internal, bukan saldo BytePlus.
- Produksi: `npm run build` lalu `npm start`.
